# Page Transitions

CSS transitions implemented with jQuery.

## Syntax

Tranitions:

- horizontal
- vertical
- horizontal-easing
- vertical-easing
- horizontal-fade
- vertical-fade

div id="page-#" role="page"

a href="#page-#" role="transition" transition="horizontal" reverse

## Demo

[Demo](http://white-git.github.io/page-transitions/)